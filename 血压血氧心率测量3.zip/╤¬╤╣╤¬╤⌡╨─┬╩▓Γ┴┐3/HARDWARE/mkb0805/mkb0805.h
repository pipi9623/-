#ifndef _MKB0805_H
#define _MKB0805_H
#include "sys.h"

void USART2_Init(u32 bound);//����2��ʼ��
void Usart_SendByte(USART_TypeDef* pUSARTx,uint8_t data);
void Usart_SendHalfWord(USART_TypeDef*  pUSARTx,uint16_t data);
void Usart_SendStr(USART_TypeDef*  pUSARTx,uint8_t *str);
void Usart_SendArray(USART_TypeDef*  pUSARTx,uint8_t  *array,uint8_t num);

#endif

