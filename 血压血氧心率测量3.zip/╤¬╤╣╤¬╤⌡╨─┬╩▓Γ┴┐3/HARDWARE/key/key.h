#ifndef __KEY_H
#define __KEY_H 

#define KEY0 PCint(5)// PC5
#define KEY1 PAint(15)// PA15	

void KEY_Init(void);
void EXTI15_10_IRQHandler(void);
#endif
