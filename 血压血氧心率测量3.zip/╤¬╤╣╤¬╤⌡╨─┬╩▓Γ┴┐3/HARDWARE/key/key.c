#include "key.h"
#include "led.h"
#include "delay.h"
#include "GUI.h"
#include "Lcd_Driver.h"

extern u8 P_H,P_L,Heart_Rate;//Ѫѹ ��ѹ/��ѹ/����
extern int32_t n_spo2;
void KEY_Init(void)
{
   EXTI_InitTypeDef  Exti_InitStructure;
   NVIC_InitTypeDef  Nvic_InitStructure;
   GPIO_InitTypeDef  GPIO_InitStructure;
	
 	 NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
	
   RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC|RCC_APB2Periph_GPIOA|RCC_APB2Periph_AFIO, ENABLE);	 //ʹ��PB,PE�˿�ʱ��
	
	 

 GPIO_InitStructure.GPIO_Pin = GPIO_Pin_5;				 //KEY0
 GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPD; 		 //��������
 GPIO_Init(GPIOC, &GPIO_InitStructure);					 //�����趨������ʼ��GPIOD.2
 GPIO_SetBits(GPIOC,GPIO_Pin_5);						 //PB.5 �����

 GPIO_InitStructure.GPIO_Pin = GPIO_Pin_15;	 
 GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPD; 	//KEY1
 GPIO_Init(GPIOA, &GPIO_InitStructure);	  				 //
 GPIO_SetBits(GPIOA,GPIO_Pin_15); 						 //
	
	GPIO_EXTILineConfig(GPIO_PortSourceGPIOA, GPIO_PinSource15);
  Exti_InitStructure.EXTI_Line = EXTI_Line15;
  Exti_InitStructure.EXTI_LineCmd = ENABLE;
  Exti_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;
	Exti_InitStructure.EXTI_Trigger = EXTI_Trigger_Falling;
	EXTI_Init(&Exti_InitStructure);
	
	Nvic_InitStructure.NVIC_IRQChannel = EXTI15_10_IRQn;
	Nvic_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	Nvic_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
	Nvic_InitStructure.NVIC_IRQChannelSubPriority = 0;
  NVIC_Init(&Nvic_InitStructure);
	
}

void EXTI15_10_IRQHandler(void)
{
	
    if(GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_15) == 0)
		{
			Lcd_Clear(GRAY0);//����
			Gui_DrawFont_GBK16(30, 0, BLACK,GRAY0, "��������");
			if(Heart_Rate<55)
			{
			Gui_DrawFont_GBK16(30,55, RED,GRAY0, "����ƫ����");
			}else if(Heart_Rate>90){
			Gui_DrawFont_GBK16(30,55, RED,GRAY0, "����ƫ�죡");
			}else{
			Gui_DrawFont_GBK16(30,55, GREEN,GRAY0, "��������");
      }
			
			if(n_spo2<95)
			{
			Gui_DrawFont_GBK16(30,30, RED,GRAY0, "Ѫ��ƫ�ͣ�");
			}else{
			Gui_DrawFont_GBK16(30,30, GREEN,GRAY0, "Ѫ������");
      }
			
				if(P_H<90||P_L<60)
			{
			Gui_DrawFont_GBK16(30,80, RED,GRAY0, "Ѫѹƫ�ͣ�");
			}else if(P_H>130||P_L>80){
			Gui_DrawFont_GBK16(30,80, RED,GRAY0, "Ѫѹƫ�ߣ�");
			}else{
			Gui_DrawFont_GBK16(30,80, GREEN,GRAY0, "Ѫѹ����");
      }
			
	EXTI_ClearITPendingBit(EXTI_Line15);//���LINE15�ϵ��жϱ�־λ
		}
}
